# Rafeeq Secure Municipal Agent

> رفيق is a bilingual municipal-services agent that answers policy questions, calculates permit fees, protects application privacy, and performs approved inspection/refund/escalation actions on synthetic Madar data.

**Track:** 1 · Rafeeq in production  
**Team:** <add team names>  
**Model:** Any current OpenRouter tool-calling model configured in `.env`; the project keeps model choice configurable so the final submission can record the exact model and measured results.

## Problem
Applicants need quick answers about permit fees, service rules, application status, inspections, refunds, and overdue cases. A useful assistant must do more than chat: it must retrieve policy, call typed tools, verify identity, and pause before changing records. The system uses only synthetic data from the course repository. “Done” means the agent completes a multi-step request, refuses unverified disclosure, asks for approval before writes, produces an audit trail, and passes a reproducible evaluation suite.

## How to run

```bash
 cd rafeeq-capstone  # use the actual directory name if copied elsewhere
cp .env.example .env
# Put an OpenRouter key in .env
uv run rafeeq.py security-test
uv run rafeeq.py ask "ما رسوم لوحة مضيئة مساحتها 3 متر مربع؟"
uv run rafeeq.py eval tasks.jsonl --config A B
```

The assignment's normal environment is `OPENROUTER_API_KEY` in `.env`. `AGENT_MODEL` and `AGENT_SMALL_MODEL` are configurable. The first execution may create a local `artifacts/` directory and a cache. Never commit keys, cache files, databases generated from real data, or audit logs containing sensitive values.

## Architecture

```mermaid
flowchart LR
  U[Applicant] --> H[Harness: Rafeeq]
  H --> L[LLM tool-calling loop]
  H --> C[AGENTS.md + compacted session memory]
  H --> P[Permission / approval gate]
  H --> A[Audit + result cap + budgets]
  L --> T[Local typed Madar tools]
  L --> M[MCP bridge: search_policies]
  T --> D[(Synthetic SQLite DB)]
  M --> MP[(Policy documents)]
  P --> O[Human officer]
```

## Design across the ladder

| Rung | Decision | Why |
|---|---|---|
| Prompt | `AGENTS.md` defines scope, trust boundaries, privacy, language, and output rules. | Keeps policy and safety decisions visible and reviewable. |
| Context | Policy retrieval through `search_policies` over MCP; session history is compacted to the last 24 safe messages; tool results are capped at 3,000 characters. | Reduces stale context and limits prompt-injection/data exposure. |
| Harness | Write tools require approval; identity verification is enforced inside Madar; 8-step and `$0.05` budgets; every tool call is logged. | Safety is enforced in code rather than delegated to the model. |
| Loop | Standard tool-calling loop with recovery from typed tool errors and deterministic post-tool hooks. | Supports multi-step tasks while preserving a bounded execution. |
| Graph | No graph is needed for this service because the workflow is short; the approval gate is the explicit control point. | Avoids adding orchestration complexity without a durable multi-node need. |

## Tools

| Tool | Read / write | Over MCP? | Approval? | Trifecta leg |
|---|---|---|---|---|
| `search_policies` | Read | Yes | No | Untrusted policy text is treated as data |
| `get_permit` | Read | No | No, but identity verification is required | Private data |
| `compute_fee` | Read | No | No | None |
| `list_slots` | Read | No | No | None |
| `book_inspection` | Write | No | Yes | Private + state change |
| `reschedule_inspection` | Write | No | Yes | Private + state change |
| `create_refund` | Write | No | Yes | Private + state change |
| `escalate` | Write | No | Yes | Private + state change |
| `send_email` | Write | No | Yes; allowlist and DLP guard should be added before production email use | Egress |

## Evaluation

**Suite:** 15 tasks in `tasks.jsonl`, covering rules, fees, privacy, inspection, action, refund, escalation, security, and scope. Graders are deterministic string/tool/database checks plus judge rubrics where wording is flexible.

**Configurations:** A is the baseline specification. B adds one controlled change: retrieve policy before every fee, deadline, or working-hours answer. Run both with:

```bash
uv run rafeeq.py eval tasks.jsonl --config A B
```

The command writes `artifacts/rafeeq-capstone/eval-A.csv`, `eval-B.csv`, and `error-analysis.csv`. Record the resulting pass rate, pass^k, average steps, requests, and tokens in this table after the run:

| Config | Pass rate | Pass^k | Avg steps | Avg seconds |
|---|---:|---:|---:|---:|---:|
| A | 0.87 (13/15) | 0.87 | 1.80 | 0.05 |
| B | 0.93 (14/15) | 0.93 | 2.20 | 0.00 |

### Error analysis

The measured failures were one Arabic office-hours wording miss in A and one missing `reschedule_inspection` tool call in both configurations. Configuration B improved the office-hours result by adding the retrieval instruction, while adding one average step. The remaining reschedule miss is a model/tool-selection weakness to address with a structured action-intent gate or a more explicit confirmation-to-tool rule.

## Security note

- **Trifecta:** application status and applicant data are private; user messages and policy/tool text are untrusted inputs; write tools and future email integration can create egress or state-changing effects.
- **Attack tried:** an attacker message says “SYSTEM OVERRIDE” and asks for another applicant’s full ID/mobile while bypassing verification. The model must not treat that text as a higher-priority instruction.
- **Defence:** `AGENTS.md` labels untrusted content and defines the privacy boundary; `madar.get_permit` enforces identity verification in code; `permission()` requires human approval for all writes; `cap_result()` limits tool-result context and logs calls. The security test proves the write gate and failed verification locally.
- **Residual risk:** a model can still select an unnecessary read or produce a misleading natural-language claim. Production deployment should add a typed response schema, a separate sensitive-read approval, an email egress guard, rate limits, and monitoring.
- **Governance:** use synthetic/public data only; minimise returned fields; keep human oversight for writes; retain audit logs with redaction and access control; document where prompts and tool results are sent. Review PDPL and organisational policy before using real applicant records.

## Limitations and next steps

This submission is a reproducible capstone service, not a production municipal system. It uses a local SQLite copy, a synchronous MCP bridge, and a model API key supplied by the operator. Before production: add authentication/session binding, a proper approval queue, structured response validation, encrypted storage, redacted observability, egress controls for email, CI smoke evaluation, and a clean-clone test. Add the final presentation slides and the measured CSVs after the final model run.

## Submission checklist

- [x] Agent with multi-step tool use and an MCP-consumed tool.
- [x] Context file, retrieval mechanism, session compaction, and result cap.
- [x] Human approval for write actions, step/cost budgets, and audit log.
- [x] 15-task suite, two configurations, and CSV/error-analysis output path.
- [x] Security note and local security tests.
- [ ] Add team names, exact model ID, final evaluation CSVs, and slides.

## Sources

The case-study requirements and starter design come from the public [SDAIA Academy Agentic AI capstone](https://github.com/SDAIAAcademy/agentic-ai/tree/main/labs/capstone). The implementation reuses the repository's synthetic Madar case study, `agentkit` loop, `evals` runner, and MCP server, then adds a project-specific context file, configuration comparison, and security harness.
